import express from 'express'
const router = express.Router()
import orgRouter from './orgnization.routes.js'
import providerRouter from './provider.routes.js'


router.use('/org', orgRouter);
router.use('/provider',providerRouter )

export default router