import mongoose, { mongo } from "mongoose";
import { SessionType } from "../utils/enums/enums.js";

const sessionModel = new mongoose.Schema({
  client: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Client",
  },
  provider: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Provider",
  },
  sessionType: {
    type: String,
    enum: [
      SessionType.Baseline_Data_Collection,
      SessionType.Progress_Monitoring,
    ],
  },
  dateOfSession: {
    type: Date,
  },
  startTime: {
    type:Date
  },
  endTime:{
    type:Date
  },
  clientVariable:{
    type:String
  },
  present:{
    type:String
  }

});

const Session = mongoose.model("Session", sessionModel)
export default Session 
