import { NextFunction, Request, Response } from "express";
import ErrorHandler from "../utils/ErrorHandler.js";
import Provider from "../models/provider.model.js";
import {
  SystemRoles,
  User_Status,
  VerficationType,
} from "../utils/enums/enums.js";
import bcrypt from "bcrypt";
import {
  defaultAdminPermissions,
  defaultUserPermissions,
  generateOtp,
  generateRandomString,
  sendMail,
} from "../utils/helper.js";
import {
  sendOtpToEmail,
  setPasswordLink,
  subjectForSendingMail,
  textForVerifyMail,
} from "../utils/MailTemplate.js";
import jwt, { JwtPayload } from "jsonwebtoken";
import Client from "../models/client.model.js";
import GoalBank from "../models/goalbank.model.js";

const login = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { email, password } = req.body;
    const Email = email.toLowerCase();
    console.log(Email);

    const provider = await Provider.findOne({
      email: Email,
      userStatus: User_Status.Active,
    });
    if (!provider) {
      return next(new ErrorHandler("User is not found", 400));
    }
    const isMatch = await bcrypt.compare(password, provider.password);
    if (!isMatch) {
      return next(new ErrorHandler("Password  didn't match."));
    }
    const otp = generateOtp();
    const html = sendOtpToEmail(otp);
    await sendMail(Email, subjectForSendingMail(), textForVerifyMail(), html);
    provider.otp = otp;

    provider.otpExpiry = new Date(Date.now() + 10 * 60 * 1000);
    await provider.save();

    return res.status(200).json({
      succcess: true,
      message: "Login successfull. Please verify Otp.",
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};

const getUserProfile = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { userId } = req;
    const findUser = await Provider.findById(userId).populate("organizationId");
    return res.status(200).json({
      success: true,
      message: "User found successfully",
      data: findUser,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};
const verifyOtp = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { otp, email, type } = req.body;

    const Email = email.toLowerCase();
    const provider = await Provider.findOne({
      email: Email,
      userStatus: User_Status.Active,
    });
    if (!provider) {
      return next(new ErrorHandler("User not found", 400));
    }
    if (provider?.otp !== otp) {
      return next(new ErrorHandler("Otp is not matched", 400));
    }
    if (provider?.otpExpiry < new Date()) {
      return next(new ErrorHandler("Otp is expired", 400));
    }
    //  if (type === VerficationType.Login) {

    //   }
    const jti = generateRandomString();
    provider.otp = null;
    provider.otpExpiry = null;
    provider.isVerified = true;
    provider.jti = jti;
    await provider.save();
    const token = jwt.sign(
      { userId: provider?._id, jti: jti },
      process.env.JWT_SECRET_KEY
    );
    return res.status(200).json({
      success: true,
      message: "Account verifued successfully..",
      data: token,
      provider,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};
const sendOtp = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { email } = req.body;
    const Email = email.toLowerCase();
    const provider = await Provider.findOne({
      email,
      userStatus: User_Status.Active,
    });
    if (!provider) {
      return next(new ErrorHandler("User not  found", 400));
    }
    const otp = generateOtp();
    const html = sendOtpToEmail(otp);
    await sendMail(Email, subjectForSendingMail(), textForVerifyMail(), html);
    provider.otp = otp;
    provider.otpExpiry = new Date(Date.now() + 10 * 60 * 1000);
    await provider.save();
    return res
      .status(200)
      .json({ success: true, message: "Otp send succcessfully." });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};
const getClients = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { user } = req;
    const clients = await Client.find({ organizationId: user?.organizationId });
    if (!clients.length) {
      return next(new ErrorHandler("Clients not found", 400));
    }
    return res.status(200).json({
      success: true,
      message: "Clients found successfully.",
      data: clients,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};
const getClientProfie = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { clientId } = req.query;
    const client = await Client.findById(clientId).populate(
      "assignedProvider",
      "clinicalSupervisor",
      "qsp"
    );
    if (!client) {
      return next(new ErrorHandler("Client not found", 400));
    }
    return res.status(200).json({
      success: true,
      message: "Client found successfully",
      data: client,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};
const addClient = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { user } = req;
    const {
      name,
      dob,
      diagnosis,
      parentName,
      email,
      phone,
      countryCode,
      assignedProvider,
      qsp,
      clinicalSupervisor,
      reviewDate,
    } = req.body;
    const client = new Client({
      name,
      diagnosis,
      dob,
      parentName,
      email,
      phone,
      assignedProvider,
      qsp,
      clinicalSupervisor,
      reviewDate,
      countryCode,
      organizationId: user?.organizationId,
    });

    await client.save();
    return res.status(200).json({
      success: true,
      message: "Client added successfully",
      data: client,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};

const updateClient = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { clientId } = req.query;
    const updateData = req.body;

    const client = await Client.findById(clientId);
    if (!client) {
      return next(new ErrorHandler("Client not found", 404));
    }

    Object.keys(updateData).forEach((key) => {
      client.set(key, updateData[key]);
    });

    await client.save();

    return res.status(200).json({
      success: true,
      message: "Client updated successfully",
      data: client,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};

const getProviders = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { user } = req;
    const providers = await Provider.find({
      organizationId: user?.organizationId,
    });
    if (!providers.length) {
      return next(new ErrorHandler("Providers Not found", 400));
    }
    return res?.status(200).json({
      success: true,
      message: "Here is your providers",
      data: providers,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};

const addProvider = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { user } = req;

    const {
      name,
      credential,
      clinicRole,
      systemRole,
      email,
      phone,
      countryCode,
      licenseNumber,
    } = req.body;
    const Email = email.toLowerCase();
    const findPrvoder = await Provider.findOne({
      email: Email,
      userStatus: User_Status.Active,
    });
    const sendSetPasswordEmail = async () => {
      const setPasswordToken = jwt.sign(
        { email: Email, tokenVersion: user.tokenVersion },
        process.env.JWT_SECRET_KEY,
        { expiresIn: "1h" }
      );
      const passwordLink = `${process.env.FRONTEND_URL}/set-account?token=${setPasswordToken}`;
      const subject = "Set Your Account Password";

      const text = `Click the link below to set your password:-\n\nThis link is valid for 1h minutes.`;

      const html = setPasswordLink(passwordLink);

      await sendMail(Email, subject, text, html);
    };
    if (findPrvoder) {
      await sendSetPasswordEmail();
      return res.status(200).json({
        success: true,
        message: "Invitation has been sent  to email.",
      });
    }
    let deafultpermissions;
    if (systemRole === SystemRoles.Admin) {
      deafultpermissions = defaultAdminPermissions;
    }
    if (systemRole === SystemRoles.User) {
      deafultpermissions = defaultUserPermissions;
    }
    // can he create
    const newProvider = new Provider({
      name,
      credential,
      clinicRole,
      systemRole,
      email: Email,
      phone,
      countryCode,
      licenseNumber,
      organizationId: user?.organizationId,
      permissions: deafultpermissions,
    });
    await newProvider.save();
    await sendSetPasswordEmail();
    return res.status(200).json({
      success: true,
      message: "Email has been send to user to set password",
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};

const setUpProviderAccount = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { token, password } = req.body;
    const decode = jwt.verify(token, process.env.JWT_SECRET_KEY) as JwtPayload;
    const provider = await Provider.findOne({ email: decode?.email });
    if (!provider) {
      return next(new ErrorHandler(" Provider not found"));
    }
    if (decode.tokenVersion !== provider?.tokenVersion) {
      return next(new ErrorHandler("Token is expired", 400));
    }
    provider.password = password;
    provider.tokenVersion = provider.tokenVersion + 1;
    await provider.save();

    return res.status(200).json({
      success: true,
      message: "Password has been set for your account",
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};
const updateProvider = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const updateData = req.body;

    const { providerId } = req.query;

    const provider = await Provider.findById(providerId);
    if (!provider) {
      return next(new ErrorHandler(" Provider not found", 400));
    }
    if (updateData.permissions) {
      updateData.permissions.forEach((perm) => {
        if (provider.permissions.includes(perm)) {
          provider.permissions = provider.permissions.filter((p) => p !== perm);
        } else {
          provider.permissions.push(perm);
        }
      });
      delete updateData.permissions;
    }

    Object.keys(updateData).forEach((key) => {
      provider.set(key, updateData[key]);
    });

    await provider.save();
    return res
      .status(200)
      .json({ success: true, message: "Provider Updated successfully" });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};

const viewPermission = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { providerId } = req.query;
    const provider = await Provider.findById(providerId);
    if (!provider) {
      return next(new ErrorHandler("Provider  not found"));
    }

    const permissions = provider?.permissions;
    return res.status(200).json({
      success: true,
      message: "Here is Permission of Provider",
      data: permissions,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};

const addGoalBank = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { user } = req;
    const { category, discription, criteriaForMastry } = req.body;

    const duplicateGoal = await GoalBank.findOne({
      category,
      discription,
      organizationId: user.organizationId,
    });

    if (duplicateGoal) {
      return res.status(409).json({
        success: false,
        message: "Goal with this description already exists in Goal Bank.",
      });
    }

    const newGoal = await GoalBank.create({
      category,
      discription,
      criteriaForMastry,
      organizationId: user.organizationId,
    });

    return res.status(201).json({
      success: true,
      message: "Goal Bank entry created successfully.",
      data: newGoal,
    });
  } catch (error) {
    console.log("error__", error);
    next(new ErrorHandler());
  }
};

const viewGoalBank = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { user } = req;
    const goals = await GoalBank.find({ organizationId: user?.organizationId });
    if (!goals.length) {
      return next(new ErrorHandler("Goals not found", 400));
    }
    return res.status(200).json({
      success: true,
      message: "Here  is  your organizations Goals",
      data: goals,
    });
  } catch (error) {
    console.log("error__", error);
    next(new ErrorHandler());
  }
};

const editGoalBank = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { user } = req;
    const { goalId } = req.query;
    const updateData = req.body;

    // Check if goal exists
    const existingGoal = await GoalBank.findOne({
      _id: goalId,
      organizationId: user.organizationId,
    });

    if (!existingGoal) {
      return res.status(404).json({
        success: false,
        message: "Goal not found.",
      });
    }

    // DUPLICATE CHECK (category + description must be unique)
    if (updateData.category || updateData.discription) {
      const duplicate = await GoalBank.findOne({
        _id: { $ne: goalId },
        category: updateData.category ?? existingGoal.category,
        discription: updateData.discription ?? existingGoal.discription,
        organizationId: user.organizationId,
      });

      if (duplicate) {
        return res.status(409).json({
          success: false,
          message:
            "Another goal with same category and description already exists.",
        });
      }
    }

    // Update record
    const updatedGoal = await GoalBank.findByIdAndUpdate(
      goalId,
      { $set: updateData },
      { new: true }
    );

    return res.status(200).json({
      success: true,
      message: "Goal Bank entry updated successfully.",
      data: updatedGoal,
    });
  } catch (error) {
    console.log("error__", error);
    next(new ErrorHandler());
  }
};

const addItpGoalsToClient = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { user } = req;
    const { goalId, targetDate, baselinePercentage, clientId } = req.body;
    const goal = await GoalBank.find({
      organizationId: user?.organizationId,
      _id: goalId,
    });

    if (!goal) {
      return next(new ErrorHandler("Goal not found", 400));
    }

    const client = await Client.findOneAndUpdate(
      {
        _id: clientId,
      },
      {
        $push: {
          itpGoals: {
            goal: goalId,
            targetDate,
            baselinePercentage,
          },
        },
      },
      { new: true }
    );
    return res.status(200).json({
      success: true,
      message: "Goal assgined to Client",
      data: client,
    });
  } catch (error) {
    console.log("error__", error);
    next(new ErrorHandler());
  }
};

const logOut = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { user } = req;
    user.jti = null;

    await user.save();

    await user.save();
    return res
      .status(200)
      .json({ success: true, message: "Logout successfully." });
  } catch (error) {
    console.log("error__", error);
    next(new ErrorHandler());
  }
};

export const providerController = {
  addProvider,
  updateProvider,
  login,
  getUserProfile,
  verifyOtp,
  sendOtp,
  getClients,
  addClient,
  getProviders,
  viewPermission,
  updateClient,
  setUpProviderAccount,
  addGoalBank,
  viewGoalBank,
  editGoalBank,
  getClientProfie,
  addItpGoalsToClient,
  logOut
};
