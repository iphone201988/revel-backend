// import { NextFunction, Request, Response } from "express";
// import ErrorHandler from "../utils/ErrorHandler.js";

// const viewAllAuditLogs = async(req: Request, res: Response, next: NextFunction)=>{
//     try {
//         const {}
//     } catch (error) {
//           console.log("error__", error);
//     next(new ErrorHandler());
//     }
// }