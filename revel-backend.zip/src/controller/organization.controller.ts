import { NextFunction, Request, Response } from "express";
import Organization from "../models/organization.model.js";
import ErrorHandler from "../utils/ErrorHandler.js";
import { generateOtp, sendMail } from "../utils/helper.js";
import {
  sendOtpToEmail,
  subjectForSendingMail,
  textForVerifyMail,
} from "../utils/MailTemplate.js";
import { ClinicRole, Permission, Status, SystemRoles, User_Status } from "../utils/enums/enums.js";
import Client from "../models/client.model.js";
import Provider from "../models/provider.model.js";

const registerOrganization = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const {
      clinicName,
      ownerFirstName,
      ownerLastName,
      email,
      phone,
      countryCode,
      clinicAddress,
      clinicCity,
      clinicState,
      clinicZip,
      password,
    } = req.body;
    const EMail = email.toLowerCase();
    // find by multiple like same  adddress and same name
    const findOrg = await Organization.findOne({
      ownerEmail: EMail,
      status: Status.Active,
    });
    if (findOrg) {
      return next(new ErrorHandler("Email is already Exist", 400));
    }

    const otp = generateOtp();
    console.log(otp,"otp");
    
    const html = sendOtpToEmail(otp);
    await sendMail(EMail, subjectForSendingMail(), textForVerifyMail, html);
    const newClinic = new Organization({
      clinicName,
      ownerFirstName,
      ownerLastName,
      ownerEmail: EMail,
      ownerPhone: phone,
      countryCode,
      clinicAddress,
      clinicCity,
      clinicState,
      clinicZip,
      password,
    });
    await newClinic.save();
    const allPermissions = Object.values(Permission)
    const provider = new Provider({
      name: ownerFirstName + ownerLastName,

      // credential,
      clinicRole: ClinicRole.QSP,
      systemRole: SystemRoles.SuperAdmin,
      email: EMail,
      isVerified: true,
      phone: phone,
      countryCode,
      // licenseNumber,

      password: password,
      otp: otp,
      otpExpiry: new Date(Date.now() + 10 * 60 * 1000),
      organizationId: newClinic._id,
      permissions: allPermissions
    });
    await provider.save();
    return  res.status(200).json({
      success: true,
      message: "Clinic Register Successfully..",
      data: newClinic,
      provider,
    });
  } catch (error) {
    console.log(error, "error__");
    next(new ErrorHandler());
  }
};





export const orgController = {
  registerOrganization,
};
