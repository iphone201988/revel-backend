import { NextFunction, Request, Response } from "express";
import ErrorHandler from "../utils/ErrorHandler.js";
import AuditLogs from "../models/auditLogs.model.js";
import { auditRouteMap } from "../utils/helper.js";

const auditLogs = async (req: Request, res: Response, next: NextFunction) => {
  res.on("finish", async () => {
    try {
      if (res?.statusCode >= 400) return;

      const { user } = req;
         console.log(user, "user");
         
      const key = `${req.method} ${req.originalUrl}`;   
      const auditMeta = auditRouteMap[key];
      if (!auditMeta) return;
      await AuditLogs.create({
        organizationId : user?.organizationId || null,
        user: user?._id || null,
        userEmail: user?.email || null,
       action: auditMeta.action,
        resource: auditMeta.resource,
        ipAddress:req.ip,

        details: {
          params: req.params,   
          query: req.query,
        },

      });
    } catch (error) {
      console.log(error, "error__");
      next(new ErrorHandler());
    }
});
next();   
};

export default auditLogs;
